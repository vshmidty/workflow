sap.ui.define([
	"./BaseController"
], function (BaseController) {
	"use strict";

	return BaseController.extend("btp.samples.simple.app.controller.DetailObjectNotFound", {});
});